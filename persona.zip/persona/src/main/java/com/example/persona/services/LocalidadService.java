package com.example.persona.services;

import com.example.persona.entities.Localidad;
import org.apache.tomcat.jni.Local;

public interface LocalidadService extends BaseService<Localidad, Long> {
}
